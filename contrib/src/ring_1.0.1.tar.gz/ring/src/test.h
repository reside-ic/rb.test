#include <R.h>
#include <Rinternals.h>
SEXP test_search_linear(SEXP r_buffer, SEXP r_value);
SEXP test_search_bisect(SEXP r_buffer, SEXP r_value, SEXP r_i);
SEXP test_advance_head(SEXP r_buffer, SEXP r_value);
