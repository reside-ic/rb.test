# ring 1.0.1

* Several small safety tweaks preventing crashes ([#13](https://github.com/richfitz/ring/issues/13))

# ring 1.0.0 (2017-04-24)

* Initial CRAN release
